import json, urllib.request, datetime
def get(u): return json.load(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "finwise"}), timeout=30))
xau = get("https://api.gold-api.com/price/XAU")["price"]      # USD per troy ounce
idr = get("https://open.er-api.com/v6/latest/USD")["rates"]["IDR"]
p = round(xau * idr / 31.1035)                                 # IDR per gram
d = datetime.date.today().isoformat()
j = json.load(open("prices.json"))
h = [x for x in j["history"] if x["d"] != d] + [{"d": d, "p": p}]
json.dump({"updated": d, "idr_per_gram": p, "history": h[-90:]}, open("prices.json", "w"))
print(d, p)
